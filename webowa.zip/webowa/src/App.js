import './App.css';
import 'bootstrap/dist/css/bootstrap.css';
import dane from './assets/dane.json';
import { useEffect, useState } from 'react';
import { Button, Image } from 'react-bootstrap';

function App() {
  const [bloki, setBloki] = useState([])
  const [pokazKwiaty, setPokazKwiaty] = useState(true)
  const [pokazZwierzeta, setPokazZwierzeta] = useState(true)
  const [pokazSamochody, setPokazSamochody] = useState(true)

  useEffect(() => {
    try {
      setBloki(dane.dane)
    } catch (error) {
      console.log(error)
    }
  }, [])

//
//   ***************************************************************
//   nazwa metody: ZmienioneBloki
//   opis metody: Filtruje bloki o te które są odznaczone przyciskami
//   parametry: brak
//   zwracany typ i opis: true albo false w zależności który przycisk mamy odznaczony
//   autor: 0017
//   ***************************************************************
  function ZmienioneBloki() {
    return bloki.filter((blok) => {
      if (blok.category == 1 && !pokazKwiaty) return false
      if (blok.category == 2 && !pokazZwierzeta) return false
      if (blok.category == 3 && !pokazSamochody) return false

      return true
    })
  }

//
//   ***************************************************************
//   nazwa metody: PrzyciskPobierz
//   opis metody: Po naciśnięciu przycisku zwiększa liczbę pobrań konkretnego bloku
//   parametry: index bloku którego pobieranie chcemy zwiększyć
//   zwracany typ i opis: brak
//   autor: 0017
//   ***************************************************************
  function PrzyciskPobierz(index) {
    setBloki((prevBloki) =>
      prevBloki.map((blok, i) =>
        i === index
          ? { ...blok, downloads: blok.downloads + 1 }
          : blok
      )
    )
  }

  return (
    <div>
      <h1>Kategorie zdjęć</h1>
      <div style={{display: "flex", flexDirection: "row"}}>
        <div className="form-check form-switch">
          <input className="form-check-input" type="checkbox" id="przyciskKwiaty" checked={pokazKwiaty} onChange={(e) => setPokazKwiaty(e.target.checked)}/>
          <label className="form-check-label" htmlFor="przyciskKwiaty">Kwiaty</label>
        </div>

        <div className="form-check form-switch">
          <input className="form-check-input" type="checkbox" id="przyciskZwierzeta" checked={pokazZwierzeta} onChange={(e) => setPokazZwierzeta(e.target.checked)}/>
          <label className="form-check-label" htmlFor="przyciskZwierzeta">Zwierzęta</label>
        </div>

        <div className="form-check form-switch">
          <input className="form-check-input" type="checkbox" id="przyciskSamochody" checked={pokazSamochody} onChange={(e) => setPokazSamochody(e.target.checked)}/>
          <label className="form-check-label" htmlFor="przyciskSamochody">Samochody</label>
        </div>
      </div>

      <div style={{display: 'flex', flexDirection: 'row', flexWrap: 'wrap'}}>
        {ZmienioneBloki().length > 0 ? ZmienioneBloki().map((blok, index) => (
          <div style={{margin: 5}} key={index}>
            <Image src={`./assets/${blok.filename}`} style={{margin: 5, borderRadius: 5}}/>
            <h4 id={index}>Pobrań: {blok.downloads}</h4>
            <Button variant='success' onClick={() => PrzyciskPobierz(index)}>Pobierz</Button>
          </div>
        )) : null}
      </div>
    </div>
  );
}

export default App;